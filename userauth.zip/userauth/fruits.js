// Import required modules
const express = require('express');

// Create an instance of Express
const app = express();

// Define Fruit class
class Fruit {
  constructor(id, name, color) {
    this.id = id;
    this.name = name;
    this.color = color;
  }
}

// Create an array of Fruit objects
const fruits = [
  new Fruit(1, 'Apple', 'Red'),
  new Fruit(2, 'Banana', 'Yellow'),
  new Fruit(3, 'Grape', 'Purple'),
  new Fruit(4, 'Orange', 'Orange'),
  new Fruit(5, 'Blueberry', 'Blue')
];

// API route to get sorted fruits by color
app.get('/fruits', (req, res) => {
  // Sort fruits array by color
  const sortedFruits = fruits.slice().sort((a, b) => a.color.localeCompare(b.color));

  // Send the sorted fruits as the response
  res.json(sortedFruits);
});

// Start the server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});
