class sort {
    constructor(id, name, color) {
      this.id = id;
      this.name = name;
      this.color = color;
    }
  }
  
  const fruits = [
    new Fruit(1, 'Apple', 'Red'),
    new Fruit(2, 'Banana', 'Yellow'),
    new Fruit(3, 'Orange', 'Orange'),
    new Fruit(4, 'Grapes', 'Purple'),
    new Fruit(5, 'Kiwi', 'Green'),
  ];
  
    module.exports = fruits;
  const express = require('express');
  const fruits = require('./fruit');
  
  const app = express();
  const port = 3000;
  
  // Define the API endpoint to return sorted fruits based on color
  app.get('/fruits', (req, res) => {
    // Sort the fruits based on color (case-insensitive)
    const sortedFruits = fruits.slice().sort((a, b) => a.color.localeCompare(b.color, undefined, { sensitivity: 'base' }));
    res.json(sortedFruits);
  });
  
  // Start the server
  app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
  });
    