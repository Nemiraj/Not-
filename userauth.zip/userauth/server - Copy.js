const express = require("express");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

// Dummy user data for demonstration
const users = [
  { username: "john123", password: "abc@123" },
  { username: "emma456", password: "password123" },
];

// Render the index page
app.get("/index", (req, res) => {
  res.render("index.ejs");
});

// Render the login page
app.get("/login", (req, res) => {
  res.render("login.ejs");
});

// Render the register page
app.get("/register", (req, res) => {
  res.render("register.ejs");
});

// Handle user registration
app.post("/register", (req, res) => {
  const { username, password } = req.body;

  // Validate username
  if (!username || !username.match(/^[a-zA-Z0-9]{6,12}$/)) {
    return res.status(400).json({ error: "Invalid username" });
  }

  // Validate password
  if (
    !password ||
    password.length < 6 ||
    !password.match(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{5,}$/)
  ) {
    return res.status(400).json({ error: "Invalid password" });
  }

  // Check if user already exists
  const user = users.find((u) => u.username === username);
  if (user) {
    return res.status(409).json({ error: "Username already exists" });
  }

  // Perform registration logic here
  // You can store the new user data in your database or in memory

  res.status(200).json({ message: "Registration successful" });
});

// Start the server
app.listen(3000, () => {
  console.log("Server started on port 3000");
});
